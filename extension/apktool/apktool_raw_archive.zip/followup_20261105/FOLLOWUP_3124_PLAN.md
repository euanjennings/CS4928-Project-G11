﻿# Separate follow-up: Apktool #3124 extraction

Status: proposed only. No #3124 metrics or test comparison has been run for this study.

## Source boundary

Compare the exact upstream parent `e69b1ed7c0d6606a24cc3cc3c51f25d0d51b3ae7` with child `a7e2e3e5e10ad223764cdac8c23cb9ee189c569f` (#3124). The commit changes 38 files, including 11 test files; it introduces `AaptInvoker` and `ResourcesDecoder` and removes `AndrolibResources`. Review all modified source and tests before attributing any metric change to Extract Class.

## Controlled measurements

1. Create separate immutable source snapshots by Git archive, retaining their hashes. Do not alter the existing Apktool study checkout.
2. Record one JDK, Gradle version, operating system, exact Gradle command, dependency resolution and every XML report hash. Run the relevant `:brut.apktool:apktool-lib:test --rerun-tasks --no-daemon --console=plain` task on each revision. Report counts, failures, skips, and testcase identity/outcome overlap. Because tests changed, do not equate unchanged counts with identical test coverage.
3. Build or identify one CK JAR at the recorded CK revision. Run identical options (`false 0 false`) and identical source scope on both revisions. Report class-level LOC, WMC, LCOM* and CBO for affected classes and the package. Do not sum CBO or LCOM* across classes as a system metric. Record raw CSV hashes and source hashes.
4. For methods that moved, compare exact signatures and bodies across revisions. Separate direct moves from rewritten, added or removed methods; track changed callers and dependencies. Explain how `AndrolibResources` responsibilities were distributed among `AaptInvoker`, `ResourcesDecoder`, `ResTable` and other classes.
5. Publish a concise before/after table with changed-test caveat, source-diff context, CK tool version and complete provenance. Keep full logs and raw tables outside PR #4 unless their data are needed for independent verification.

## Decision gate

This is a new experiment, beyond the one-field cleanup. Obtain Cian's agreement on its scope and destination before running or adding it to a pull request. No causal claim should be made from CK deltas alone because #3124 includes other production and test changes.
